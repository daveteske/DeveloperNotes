﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace kill
{
    [Table("InventoryUpdate")]
    public class InventoryUpdate
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int InventoryUpdateId { get; set; }
        public string UpdateType { get; set; }
        public string Title { get; set; }
        public string Filename { get; set; }
    }
}