﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Xml.Serialization;
using Dapper;
using Dapper.FastCrud;

namespace kill
{
    class Program
    {
        static void Main(string[] args)
        {
            var filename = @"C:\Users\DaveT\source\repos\kill\kill\20171021.bsx";
            var outFile = @"C:\Users\DaveT\source\repos\kill\kill\20171021-out.bsx";

            var xmlInputData = File.ReadAllText(filename);
            var outPut = XmlUtils.Deserialize<BrickStockXML>(xmlInputData);

            //Create some identifier of this session and partout file

            // db structure:
            // InventoryUpdate
            // InventroyUpdateItem
            var InventoryUpdates = new List<InventoryUpdate>();
            var InventoryUpdateItems = new List<InventoryUpdateItem>();

            // insert header
            InventoryUpdates.Add(new InventoryUpdate()
            {
                InventoryUpdateId = 1,
                Filename = filename,
                Title = "My cool title",
                UpdateType = "Sold offline"
            });

            // and now the items
            var counter = 1;
            foreach (var item in outPut.Inventory)
            {
                counter++;
                InventoryUpdateItems.Add(new InventoryUpdateItem()
                {
                    InventoryUpdateItemId = counter,
                    InventoryUpdateId = 1,
                    CategoryID = item.CategoryID,
                    CategoryName = item.CategoryName,
                    ColorID = item.ColorID,
                    ColorName = item.ColorName,
                    Comments = item.Comments,
                    Condition = item.Condition,
                    ItemID = item.ItemID,
                    ItemName = item.ItemName,
                    ItemTypeID = item.ItemTypeID,
                    ItemTypeName = item.ItemTypeName,
                    LotID = Convert.ToInt32(item.LotID),
                    Price = item.Price,
                    Qty = item.Qty,
                    Remarks = item.Remarks,
                    Sale = item.Sale,
                    SaleSpecified = item.SaleSpecified,
                    Status = item.Status
                });
            }

            // send it off to be edited
            Console.WriteLine("Edit Me");

            // now how do we recreate the xml file from the DB
            var newBSXML = new BrickStockXML();
            var newBSXMLItems = new List<BrickStockXMLItem>();
            foreach (var row in InventoryUpdateItems)
            {
                newBSXMLItems.Add(new BrickStockXMLItem()
                {
                    CategoryID = row.CategoryID,
                    CategoryName = row.CategoryName,
                    ColorID = Convert.ToByte(row.ColorID),
                    ColorName = row.ColorName,
                    Comments = row.Comments,
                    Condition = row.Condition,
                    ItemID = row.ItemID,
                    ItemName = row.ItemName,
                    ItemTypeID = row.ItemTypeID,
                    ItemTypeName = row.ItemTypeName,
                    LotID = Convert.ToUInt32(row.LotID),
                    Price = row.Price,
                    Qty = Convert.ToUInt16(row.Qty),
                    Remarks = row.Remarks,
                    Sale = Convert.ToByte(row.Sale),
                    SaleSpecified = row.SaleSpecified,
                    Status = row.Status
                });
            }
            newBSXML.Inventory = newBSXMLItems.ToArray();

            // so here we have the new bsx classes full of data
            var newBsx = XmlUtils.Serialize<BrickStockXML>(newBSXML);

            File.WriteAllText(outFile, newBsx, System.Text.Encoding.UTF8);

            Console.WriteLine("and back");

            var connString= new SQLiteConnectionStringBuilder(){
                DataSource = @"C:\Users\DaveT\source\repos\kill\kill\kill.db"
            }.ToString();

            OrmConfiguration.DefaultDialect = SqlDialect.SqLite;

            using (var conn = new SQLiteConnection(connString))
            {
                conn.Open();
                //using (var trans = conn.BeginTransaction())
                //{
                var newHeader = new InventoryUpdate()
                {
                    Filename = filename,
                    Title = "The thing Fast",
                    UpdateType = "Something"
                };

                conn.Insert(newHeader);
                //}

                foreach (var row in InventoryUpdateItems)
                {
                    var newItem = new InventoryUpdateItem()
                    {
                        InventoryUpdateId = newHeader.InventoryUpdateId,
                        CategoryID = row.CategoryID,
                        CategoryName = row.CategoryName,
                        ColorID = row.ColorID,
                        ColorName = row.ColorName,
                        Comments = row.Comments,
                        Condition = row.Condition,
                        ItemID = row.ItemID,
                        ItemName = row.ItemName,
                        ItemTypeID = row.ItemTypeID,
                        ItemTypeName = row.ItemTypeName,
                        LotID = row.LotID,
                        Price = row.Price,
                        Qty = row.Qty,
                        Remarks = row.Remarks,
                        Sale = row.Sale,
                        SaleSpecified = row.SaleSpecified,
                        Status = row.Status
                    };

                    conn.Insert(newItem);
                }
            }
        }
    }


    // -----------------------------

    // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class BrickStockXML
    {

        private BrickStockXMLItem[] inventoryField;

        private BrickStockXMLGuiState guiStateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Item", IsNullable = false)]
        public BrickStockXMLItem[] Inventory
        {
            get
            {
                return this.inventoryField;
            }
            set
            {
                this.inventoryField = value;
            }
        }

        /// <remarks/>
        public BrickStockXMLGuiState GuiState
        {
            get
            {
                return this.guiStateField;
            }
            set
            {
                this.guiStateField = value;
            }
        }

    }

    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class BrickStockXMLItem
    {
        private string itemIDField;

        private string itemTypeIDField;

        private byte colorIDField;

        private string itemNameField;

        private string itemTypeNameField;

        private string colorNameField;

        private ushort categoryIDField;

        private string categoryNameField;

        private string statusField;

        private ushort qtyField;

        private decimal priceField;

        private string conditionField;

        private byte saleField;

        private bool saleFieldSpecified;

        private string commentsField;

        private string remarksField;

        private uint lotIDField;

        /// <remarks/>
        public string ItemID
        {
            get
            {
                return this.itemIDField;
            }
            set
            {
                this.itemIDField = value;
            }
        }

        /// <remarks/>
        public string ItemTypeID
        {
            get
            {
                return this.itemTypeIDField;
            }
            set
            {
                this.itemTypeIDField = value;
            }
        }

        /// <remarks/>
        public byte ColorID
        {
            get
            {
                return this.colorIDField;
            }
            set
            {
                this.colorIDField = value;
            }
        }

        /// <remarks/>
        public string ItemName
        {
            get
            {
                return this.itemNameField;
            }
            set
            {
                this.itemNameField = value;
            }
        }

        /// <remarks/>
        public string ItemTypeName
        {
            get
            {
                return this.itemTypeNameField;
            }
            set
            {
                this.itemTypeNameField = value;
            }
        }

        /// <remarks/>
        public string ColorName
        {
            get
            {
                return this.colorNameField;
            }
            set
            {
                this.colorNameField = value;
            }
        }

        /// <remarks/>
        public ushort CategoryID
        {
            get
            {
                return this.categoryIDField;
            }
            set
            {
                this.categoryIDField = value;
            }
        }

        /// <remarks/>
        public string CategoryName
        {
            get
            {
                return this.categoryNameField;
            }
            set
            {
                this.categoryNameField = value;
            }
        }

        /// <remarks/>
        public string Status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }

        /// <remarks/>
        public ushort Qty
        {
            get
            {
                return this.qtyField;
            }
            set
            {
                this.qtyField = value;
            }
        }

        /// <remarks/>
        public decimal Price
        {
            get
            {
                return this.priceField;
            }
            set
            {
                this.priceField = value;
            }
        }

        /// <remarks/>
        public string Condition
        {
            get
            {
                return this.conditionField;
            }
            set
            {
                this.conditionField = value;
            }
        }

        /// <remarks/>
        public byte Sale
        {
            get
            {
                return this.saleField;
            }
            set
            {
                this.saleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool SaleSpecified
        {
            get
            {
                return this.saleFieldSpecified;
            }
            set
            {
                this.saleFieldSpecified = value;
            }
        }

        /// <remarks/>
        public string Comments
        {
            get
            {
                return this.commentsField;
            }
            set
            {
                this.commentsField = value;
            }
        }

        /// <remarks/>
        public string Remarks
        {
            get
            {
                return this.remarksField;
            }
            set
            {
                this.remarksField = value;
            }
        }

        /// <remarks/>
        public uint LotID
        {
            get
            {
                return this.lotIDField;
            }
            set
            {
                this.lotIDField = value;
            }
        }
    }

    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class BrickStockXMLGuiState
    {

        private BrickStockXMLGuiStateItemView itemViewField;

        private string applicationField;

        private byte versionField;

        /// <remarks/>
        public BrickStockXMLGuiStateItemView ItemView
        {
            get
            {
                return this.itemViewField;
            }
            set
            {
                this.itemViewField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Application
        {
            get
            {
                return this.applicationField;
            }
            set
            {
                this.applicationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte Version
        {
            get
            {
                return this.versionField;
            }
            set
            {
                this.versionField = value;
            }
        }
    }

    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class BrickStockXMLGuiStateItemView
    {

        private string columnOrderField;

        private string columnWidthsField;

        private string columnWidthsHiddenField;

        private byte sortColumnField;

        private string sortDirectionField;

        /// <remarks/>
        public string ColumnOrder
        {
            get
            {
                return this.columnOrderField;
            }
            set
            {
                this.columnOrderField = value;
            }
        }

        /// <remarks/>
        public string ColumnWidths
        {
            get
            {
                return this.columnWidthsField;
            }
            set
            {
                this.columnWidthsField = value;
            }
        }

        /// <remarks/>
        public string ColumnWidthsHidden
        {
            get
            {
                return this.columnWidthsHiddenField;
            }
            set
            {
                this.columnWidthsHiddenField = value;
            }
        }

        /// <remarks/>
        public byte SortColumn
        {
            get
            {
                return this.sortColumnField;
            }
            set
            {
                this.sortColumnField = value;
            }
        }

        /// <remarks/>
        public string SortDirection
        {
            get
            {
                return this.sortDirectionField;
            }
            set
            {
                this.sortDirectionField = value;
            }
        }
    }

}
