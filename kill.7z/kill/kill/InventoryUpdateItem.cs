﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace kill
{
    [Table("InventoryUpdateItem")]
    public class InventoryUpdateItem
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int InventoryUpdateItemId { get; set; }
        public int InventoryUpdateId { get; set; }
        public string ItemID { get; set; }
        public string ItemTypeID { get; set; }
        public int ColorID { get; set; }
        public string ItemName { get; set; }
        public string ItemTypeName { get; set; }
        public string ColorName { get; set; }
        public ushort CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string Status { get; set; }
        public int Qty { get; set; }
        public decimal Price { get; set; }
        public string Condition { get; set; }
        public int Sale { get; set; }
        public bool SaleSpecified { get; set; }
        public string Comments { get; set; }
        public string Remarks { get; set; }
        public Int32 LotID { get; set; }
    }
}

